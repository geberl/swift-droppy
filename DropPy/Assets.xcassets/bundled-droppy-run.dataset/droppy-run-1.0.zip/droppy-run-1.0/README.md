# droppy-run

The Python module that the **DropPy** macOS app launches for running a *Task*.

## Workspace repository

The *Workspace* that contains all the *Workflows*, *Tasks* and *Images* that come with the **DropPy** macOS app is also open source.

[https://github.com/geberl/droppy-workspace](https://github.com/geberl/droppy-workspace)

## Product page

[https://droppyapp.com](https://droppyapp.com)
