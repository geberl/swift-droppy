# droppy-workspace

All the *Workflows*, *Tasks* and *Images* that come with the **DropPy** macOS app.

## Tests

Make sure the *pytest* package is installed:

    python -m pytest --version

Install it if it is not:

    pip install pytest

Change into the directory of the *Task* you want to test:

    cd Tasks/Filter.OnlyDirectories

Execute *pytest* using the interpreter of your choice here:

    python -m pytest -v

    /Library/Frameworks/Python.framework/Versions/3.6/bin/python3 -m pytest -v

Documentation:

- [pytest](https://docs.pytest.org/en/latest/)
- [py.path](http://py.readthedocs.io/en/latest/path.html)

Notes:

- Running *pytest* over the complete `Tasks` directory at once is not possible since all the modules have the same filename `task.py`.

## Run repository

The Python module that the **DropPy** macOS app launches for running a *Task* is also open source.

[https://github.com/geberl/droppy-run](https://github.com/geberl/droppy-run)

## Product page

[https://droppyapp.com](https://droppyapp.com)

