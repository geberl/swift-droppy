#!/usr/bin/python
# -*- coding: utf-8 -*-

from ctypes import cdll, byref, Structure, c_char, c_char_p
from ctypes.util import find_library
import json
import os
from shutil import rmtree

FILES_JSON_NAME = 'files.json'
PATHS_ATTRIBUTE = 'files'


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        delete_to_trash = kwargs.get('delete_to_trash', True)

        original_paths = self.get_original_paths(input_paths)

        for original_path in original_paths:
            if os.path.isfile(original_path):
                self.delete_file(delete_to_trash, original_path)
            elif os.path.isdir(original_path):
                self.delete_tree(delete_to_trash, original_path)

        # Note: There is no subsequent output for the next Task.
        #       Put this Task at the end or use a Splitter before it.

    @staticmethod
    def get_original_paths(input_paths):
        json_path = os.path.abspath(os.path.join(input_paths[0],
                                                 os.pardir,
                                                 os.pardir,
                                                 FILES_JSON_NAME))

        with open(json_path, 'r') as file_handler:
            files_dict = json.loads(file_handler.read())

        return files_dict[PATHS_ATTRIBUTE]

    @classmethod
    def delete_file(cls, delete_to_trash, file_path):
        if delete_to_trash:
            print('Moving file to Trash: %s' % file_path.encode('utf-8'))
            cls.delete_to_trash(file_path)
        else:
            print('Removing file: %s' % file_path.encode('utf-8'))
            os.remove(file_path)

    @classmethod
    def delete_tree(cls, delete_to_trash, directory_path):
        if delete_to_trash:
            print('Moving directory to Trash: %s' %
                  directory_path.encode('utf-8'))
            cls.delete_to_trash(directory_path)
        else:
            print('Removing directory: %s' % directory_path.encode('utf-8'))
            rmtree(directory_path)

    @staticmethod
    def delete_to_trash(item_path):
        """
        Heavily influenced by "Send2Trash" by Virgil Dupras (hsoft)
        Source: https://github.com/hsoft/send2trash/
        """

        def check_op_result(op_result_str):
            if op_result_str:
                msg = get_macos_status_comment_string(op_result_str).\
                    decode('utf-8')
                raise OSError(msg)

        foundation = cdll.LoadLibrary(find_library('Foundation'))
        core_services = cdll.LoadLibrary(find_library('CoreServices'))
        get_macos_status_comment_string = foundation.GetMacOSStatusCommentString
        get_macos_status_comment_string.restype = c_char_p

        fp = FSRef()

        kfs_path_make_ref_do_not_follow_leaf_symlink = 0x01
        opts = kfs_path_make_ref_do_not_follow_leaf_symlink
        fs_path_make_ref_with_options = core_services.FSPathMakeRefWithOptions
        op_result = fs_path_make_ref_with_options(item_path.encode('utf-8'),
                                                  opts, byref(fp), None)
        check_op_result(op_result)

        kfs_file_operation_default_options = 0
        opts = kfs_file_operation_default_options
        fs_move_object_to_trash_sync = core_services.FSMoveObjectToTrashSync
        op_result = fs_move_object_to_trash_sync(byref(fp), None, opts)
        check_op_result(op_result)


class FSRef(Structure):
    _fields_ = [('hidden', c_char * 80)]
