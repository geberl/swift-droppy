#!/usr/bin/python3
# -*- coding: utf-8 -*-

from task import Task
import re

H1_SETEX_STYLE_REGEX = re.compile('^-+$')
H2_SETEX_STYLE_REGEX = re.compile('^=+$')
ATX_STYLE_REGEX = re.compile('^#{1,6} .*$')


# Spec: http://spec.commonmark.org/0.27/


class AddToc(Task):
    def __init__(self, file_system_item, target_dir, expects, toc_header):
        super(AddToc, self).__init__(file_system_item, target_dir, expects)

        self.toc_header = toc_header

        self.headers = []
        self.previous_line_content = ''

        if not self.pass_execution:
            # Parse source file.
            with open(self.source_item, 'r') as file_handler:
                inside_code_block = False
                for line in file_handler.readlines():
                    # Skip fenced code blocks.
                    if inside_code_block:
                        if line.startswith('```') or line.startswith('~~~'):
                            # We were in a code block but this line ended it, toggle mode and continue with next line.
                            inside_code_block = False
                            continue
                        else:
                            # We are still in a code block, continue with next line.
                            continue
                    else:
                        if line.startswith('```') or line.startswith('~~~'):
                            # We are now in a code block, toggle mode and continue with next line.
                            inside_code_block = True
                            continue

                    # Ignore lines indented by tab or 4x spaces.
                    if line.startswith('\t') or line.startswith('    '):
                        continue

                    # Detect the two types of headers.
                    if H1_SETEX_STYLE_REGEX.match(line):
                        self.add_header(text=self.previous_line_content.strip(),
                                        level=1,
                                        kind='setex')
                    elif H2_SETEX_STYLE_REGEX.match(line):
                        self.add_header(text=self.previous_line_content.strip(),
                                        level=2,
                                        kind='setex')
                    elif ATX_STYLE_REGEX.match(line):
                        self.add_header(text=self.clean_atx_content(line.strip()),
                                        level=self.detect_atx_level(line),
                                        kind='atx')
                    else:
                        # Remember line's content when checking the next line (if setex style header is detected then).
                        self.previous_line_content = line.strip()

            # Write target file.
            with open(self.target_item, 'w') as target_file_handler:
                # Start the new file with the TOC header.
                target_file_handler.write('%s\n\n' % self.toc_header)

                # Add the TOC itself.
                previous_level = 1
                level_array = [0, 0, 0, 0, 0, 0]
                for text, current_level in self.headers:
                    level_array[current_level - 1] += 1
                    if current_level < previous_level:
                        for index in range(current_level, len(level_array)):
                            level_array[index] = 0

                    target_file_handler.write('%s %d. [%s](#%s)\n' % ('\t' * (current_level - 1),
                                                                      level_array[current_level-1],
                                                                      text,
                                                                      self.generate_anchor(text)))

                    # For next item.
                    previous_level = current_level

                # Then add a horizontal rule.
                target_file_handler.write('\n---\n\n')

                # Finally add the rest of the content of the source file.
                with open(self.source_item, 'r') as source_file_handler:
                    for line in source_file_handler.readlines():
                        # TODO skip the previously existing TOC
                        target_file_handler.write(line)

    def add_header(self, text, level, kind):
        if kind == 'setex':
            if self.previous_line_content == '':  # ignore horizontal rules
                return

        self.headers.append([text, level])
        self.previous_line_content = ''

    @staticmethod
    def generate_anchor(text):
        # Convert spaces to hyphens and lowercase.
        anchor_text = text.lower().replace(' ', '-')

        # Remove every special character except hyphens, but kepp the usual unicode characters.
        return re.sub('([^\w\- üöäßéèêáàâóòô]|_)+', '', anchor_text)

    @staticmethod
    def detect_atx_level(line_content):
        for m, character in enumerate(line_content):
            if character == ' ':
                return m

    @staticmethod
    def clean_atx_content(line_content):
        clean_line = line_content

        for character in clean_line:
            if character == '#':
                clean_line = clean_line[1:]
            else:
                break

        for character in reversed(clean_line):
            if character == '#':
                clean_line = clean_line[:-1]
            else:
                break

        return clean_line.strip()
