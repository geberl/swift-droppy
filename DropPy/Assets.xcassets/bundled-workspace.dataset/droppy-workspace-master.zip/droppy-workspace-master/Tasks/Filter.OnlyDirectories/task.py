#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import os
from distutils.dir_util import copy_tree


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):

        for input_path in input_paths:
            if os.path.isfile(input_path):
                print('Skipping file: %s' % input_path)
            elif os.path.isdir(input_path):
                target_name = os.path.basename(input_path)
                copy_tree(input_path, os.path.join(output_path, target_name))
