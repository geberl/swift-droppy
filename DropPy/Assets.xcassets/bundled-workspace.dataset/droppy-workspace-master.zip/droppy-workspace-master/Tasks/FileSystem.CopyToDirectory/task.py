#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from shutil import copyfile
from distutils.dir_util import copy_tree
import sys


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        directory = kwargs.get('directory', u'')
        create = kwargs.get('create_directory', False)
        overwrite = kwargs.get('overwrite_existing', False)

        self.check_target_directory(directory, create)

        for input_path in input_paths:
            target_name = os.path.basename(input_path)
            target_path = os.path.join(directory, target_name)

            if os.path.isfile(input_path):
                # Copy the file to the user's specified target directory.
                self.copy_file(input_path, target_path, overwrite)

                # Also copy the file to the Task's output path.
                # Needed to make it available for eventually following Tasks.
                self.copy_file(input_path,
                               os.path.join(output_path, target_name), False)

                print('Successfully copied file: %s' %
                      target_name.encode('utf-8'))

            elif os.path.isdir(input_path):
                # Copy the directory to the user's specified target directory.
                self.copy_tree(input_path, target_path, overwrite)

                # Also copy the file to the Task's output path.
                # Needed to make it available for eventually following Tasks.
                self.copy_tree(input_path,
                               os.path.join(output_path, target_name), False)

                print('Successfully copied directory: %s' %
                      target_name.encode('utf-8'))

    @staticmethod
    def check_target_directory(directory, create):
        if os.path.isdir(directory):
            print('Target directory exists: %s' % directory.encode('utf-8'))
            return
        else:
            if create:
                os.makedirs(directory)
                print('Target directory created: %s' %
                      directory.encode('utf-8'))
            else:
                sys.exit('Target directory does NOT exist and parameter '
                         '"create_directory" set to False: %s' %
                         directory.encode('utf-8'))

    @staticmethod
    def copy_file(input_path, target_path, overwrite):
        if os.path.isfile(target_path):
            if overwrite:
                copyfile(input_path, target_path)
                print('File exists, overwriting')
            else:
                sys.exit('File exists, unable to continue: %s' %
                         target_path.encode('utf-8'))
        else:
            copyfile(input_path, target_path)

    @staticmethod
    def copy_tree(input_path, target_path, overwrite):
        if os.path.isdir(target_path):
            if overwrite:
                print('Directory exists, overwriting')
                copy_tree(input_path, target_path)
            else:
                sys.exit('Directory exists, unable to continue: %s' %
                         target_path.encode('utf-8'))
        else:
            copy_tree(input_path, target_path)
