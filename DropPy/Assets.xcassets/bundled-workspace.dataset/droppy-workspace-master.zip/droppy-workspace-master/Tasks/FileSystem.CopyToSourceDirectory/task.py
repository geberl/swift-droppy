#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import os
from shutil import copyfile
from distutils.dir_util import copy_tree
import sys

FILES_JSON_NAME = 'files.json'
PATHS_ATTRIBUTE = 'files'


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        overwrite = kwargs.get('overwrite_existing', False)

        source_path = self.get_original_path(input_paths)
        print('Source path: %s' % source_path.encode('utf-8'))

        for input_path in input_paths:
            target_name = os.path.basename(input_path)
            target_path = os.path.join(source_path, target_name)

            if os.path.isfile(input_path):
                self.copy_file(input_path, target_name, target_path, overwrite)
            elif os.path.isdir(input_path):
                self.copy_tree(input_path, target_name, target_path, overwrite)

    @staticmethod
    def get_original_path(input_paths):
        json_path = os.path.abspath(os.path.join(input_paths[0],
                                                 os.pardir,
                                                 os.pardir,
                                                 FILES_JSON_NAME))

        with open(json_path, 'r') as file_handler:
            files_dict = json.loads(file_handler.read())

        original_path = os.path.abspath(
            os.path.join(files_dict[PATHS_ATTRIBUTE][0], os.pardir))

        if len(files_dict['files']) > 1:
            for file_path in files_dict[PATHS_ATTRIBUTE][1:]:
                this_path = os.path.abspath(os.path.join(file_path, os.pardir))
                if original_path != this_path:
                    sys.exit('Files originate from different source '
                             'directories!')

        return original_path

    @staticmethod
    def copy_file(input_path, target_name, target_path, overwrite):
        if os.path.isfile(target_path):
            if overwrite:
                print('File exists, overwriting')
                copyfile(input_path, target_path)
            else:
                sys.exit('File exists, unable to continue: %s' %
                         target_path.encode('utf-8'))
        else:
            copyfile(input_path, target_path)

        print('Successfully copied file: %s' % target_name.encode('utf-8'))

    @staticmethod
    def copy_tree(input_path, target_name, target_path, overwrite):
        if os.path.isdir(target_path):
            if overwrite:
                print('Directory exists, overwriting')
                copy_tree(input_path, target_path)
            else:
                sys.exit('Directory exists, unable to continue: %s' %
                         target_path.encode('utf-8'))
        else:
            copy_tree(input_path, target_path)

        print('Successfully copied directory: %s' % target_name.encode('utf-8'))
