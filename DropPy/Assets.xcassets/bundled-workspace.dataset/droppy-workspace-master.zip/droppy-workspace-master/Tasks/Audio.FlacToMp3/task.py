#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import subprocess

FLAC_EXECUTABLE = '/usr/local/bin/flac'
LAME_EXECUTABLE = '/usr/local/bin/lame'
METAFLAC_EXECUTABLE = '/usr/local/bin/metaflac'


def get_tag(file_path, key):
    command = [METAFLAC_EXECUTABLE, file_path, '--show-tag=%s' % key]
    p = subprocess.Popen(command,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    out, _ = p.communicate()

    # TODO remove this workaround for wrong encoded special chars.
    # This only occurs when running through Swift/run.py, not via PyCharm.
    # Somehow an ö is suddenly \"o, so no special chars are included, so any decode/encode efforts fail.
    # Also any locale setting efforts failed.
    tag_value = out.replace('"o', 'ö')
    tag_value = tag_value.replace('"O', 'Ö')
    tag_value = tag_value.replace('"a', 'ä')
    tag_value = tag_value.replace('"A', 'Ä')
    tag_value = tag_value.replace('"u', 'ü')
    tag_value = tag_value.replace('"U', 'Ü')
    tag_value = tag_value.replace('"', '').replace('\'', '').replace('`', '')

    return tag_value.decode('utf-8')


def normalize_tag(key_value):
    # Cut off the key part of the string (e.g. "tag=").
    value = key_value[key_value.find('=') + 1:]

    # No spaces at the beginning and no line breaks anywhere.
    value = value.strip()

    # Reliably capitalize each single word.
    # Just using .title() doesn't work well for single letter words.
    value = ' '.join(word.capitalize() for word in value.split())

    # Additional step needed to capitalize the first word inside brackets.
    for bracket_type in ['(', '[', '{']:
        if bracket_type in value:
            value = capitalize_after_char(value, bracket_type)

    return value


def capitalize_after_char(string, char):
    tmp = []
    for word in string.split(char):
        tmp.append(word[0].upper() + word[1:])
    return char.join(tmp)


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        quality = kwargs.get('quality', 'V0')
        extension = kwargs.get('extension', '.mp3')

        for input_path in input_paths:
            if os.path.isfile(input_path):
                self.transcode_file(input_path, output_path, quality, extension)

            elif os.path.isdir(input_path):
                output_sub_dir = os.path.join(output_path,
                                              os.path.basename(input_path))

                os.makedirs(output_sub_dir)
                contained_files = self.get_file_paths_from_directory(input_path)

                for contained_file in contained_files:
                    self.transcode_file(contained_file, output_sub_dir,
                                        quality, extension)

    @staticmethod
    def get_file_paths_from_directory(start_directory):
        results = []
        for root, dirs, files in os.walk(start_directory):
            for f in files:
                results.append(os.path.join(root, f))
        return results

    @staticmethod
    def transcode_file(input_path, output_path, quality, extension):
        input_file_name = os.path.basename(input_path)
        extension_pos = input_file_name.rfind('.')
        output_file_name = input_file_name[:extension_pos] + extension

        # Piping flac output into lame leads to a file with no tags at all.
        # Get all relevant tags from the source file beforehand.
        # Album art is omitted on purpose.
        tag_artist = normalize_tag(get_tag(input_path, 'ARTIST'))
        tag_title = normalize_tag(get_tag(input_path, 'TITLE'))
        tag_track_number = normalize_tag(get_tag(input_path, 'TRACKNUMBER'))
        tag_album = normalize_tag(get_tag(input_path, 'ALBUM'))
        tag_date = normalize_tag(get_tag(input_path, 'DATE'))
        tag_genre = normalize_tag(get_tag(input_path, 'GENRE'))
        tag_disk = normalize_tag(get_tag(input_path, 'DISCNUMBER'))

        # Transcode by piping the flac output into the lame encoder.
        command = u'%s -c -d "%s" |' % (FLAC_EXECUTABLE, input_path)
        command += u' %s -%s' % (LAME_EXECUTABLE, quality)
        command += u' --add-id3v2 --pad-id3v2 --ignore-tag-errors'
        command += u' --ta "%s"' % tag_artist
        command += u' --tt "%s"' % tag_title
        command += u' --tn "%s"' % tag_track_number
        command += u' --tl "%s"' % tag_album
        command += u' --tg "%s"' % tag_genre
        command += u' --ty "%s"' % tag_date
        command += u' --tv "TPOS=%s"' % tag_disk
        command += u' - "%s"' % os.path.join(output_path, output_file_name)

        subprocess.call(command, shell=True)
