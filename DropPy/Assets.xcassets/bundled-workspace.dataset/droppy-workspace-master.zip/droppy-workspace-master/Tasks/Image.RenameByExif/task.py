#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from PIL import Image, ExifTags
from shutil import copyfile


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):

        for input_path in input_paths:
            if os.path.isfile(input_path):
                self.rename_file(input_path, output_path)

            elif os.path.isdir(input_path):
                output_sub_dir = os.path.join(output_path,
                                              os.path.basename(input_path))
                os.makedirs(output_sub_dir)

                contained_files = self.get_file_paths_from_directory(input_path)
                for contained_file in contained_files:
                    self.rename_file(contained_file, output_sub_dir)

    @staticmethod
    def get_file_paths_from_directory(start_directory):
        results = []
        for root, dirs, files in os.walk(start_directory):
            for f in files:
                results.append(os.path.join(root, f))
        return results

    @staticmethod
    def rename_file(input_path, output_path):
        output_file_name = os.path.basename(input_path)

        try:
            input_image = Image.open(input_path)
            # noinspection PyProtectedMember
            for key, value in input_image._getexif().items():
                if key in ExifTags.TAGS:
                    if ExifTags.TAGS[key] == 'DateTimeOriginal':
                        output_file_name = value.replace(':', '')
                        output_file_name = output_file_name.replace(' ', '_')
                        output_file_name += '.jpg'
        except Exception as err:
            print('Unable to read EXIF tag from image at "%s"' % input_path)
            print(err)

        copyfile(input_path, os.path.join(output_path, output_file_name))
