#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import os
from shutil import copyfile


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):

        for input_path in input_paths:
            if os.path.isfile(input_path):
                target_name = os.path.basename(input_path)
                copyfile(input_path, os.path.join(output_path, target_name))
            elif os.path.isdir(input_path):
                print('Skipping directory: %s' % input_path)
