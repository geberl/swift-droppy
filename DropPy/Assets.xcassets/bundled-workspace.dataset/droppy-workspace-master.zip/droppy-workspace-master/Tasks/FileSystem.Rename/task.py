#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import os
from shutil import copyfile
from distutils.dir_util import copy_tree


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        name = kwargs.get('name', 'new_name.ext')

        for input_path in input_paths:
            new_output_path = self.get_path_counter(output_path, name)

            if os.path.isfile(input_path):
                copyfile(input_path, new_output_path)
            elif os.path.isdir(input_path):
                copy_tree(input_path, new_output_path)

    @staticmethod
    def get_path_counter(output_path, name):
        path_without_counter = os.path.join(output_path, name)

        if os.path.isfile(path_without_counter) or \
                os.path.isdir(path_without_counter):

            counter = 1
            no_ext, ext = os.path.splitext(name)
            while True:
                name_with_counter = no_ext + ' copy %s' % counter + ext
                path_with_counter = os.path.join(output_path,
                                                 name_with_counter)
                if os.path.isfile(path_with_counter):
                    counter += 1
                else:
                    return path_with_counter
        else:
            return path_without_counter
