#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from PIL import Image


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        width = kwargs.get('width', 800)
        height = kwargs.get('height', 600)

        for input_path in input_paths:
            if os.path.isfile(input_path):
                self.resize_file(input_path, width, height, output_path)

            elif os.path.isdir(input_path):
                output_sub_dir = os.path.join(output_path,
                                              os.path.basename(input_path))
                os.makedirs(output_sub_dir)

                contained_files = self.get_file_paths_from_directory(input_path)
                for contained_file in contained_files:
                    self.resize_file(contained_file, width, height,
                                     output_sub_dir)

    @staticmethod
    def resize_file(input_path, width, height, output_path):
        output_file_name = os.path.basename(input_path)

        input_image = Image.open(input_path)
        output_image = input_image.resize((width, height), Image.ANTIALIAS)
        output_image.save(os.path.join(output_path, output_file_name))

    @staticmethod
    def get_file_paths_from_directory(start_directory):
        results = []
        for root, dirs, files in os.walk(start_directory):
            for f in files:
                results.append(os.path.join(root, f))
        return results
