#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import subprocess

"""
Note: Some other interesting command line utilities of Calibre can be found at the same location:

- ebook-meta: Read/Write metadata from/to ebook files
- ebook-polish: Maybe better results when converting from epub/azw3 to other formats (?)
- ebook-device: Manage a connected ebook reader device
"""


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        extension = kwargs.get('extension', '.mobi')
        executable = '/Applications/calibre.app/Contents/MacOS/ebook-convert'

        for input_path in input_paths:
            if os.path.isfile(input_path):

                input_file_name = os.path.basename(input_path)
                extension_pos = input_file_name.rfind('.')
                output_file_name = input_file_name[:extension_pos] + extension

                subprocess.call([executable,
                                 input_path,
                                 os.path.join(output_path, output_file_name)])
