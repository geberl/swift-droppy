#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import os
from PIL import Image


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        extension = kwargs.get('extension', '.png')

        for input_path in input_paths:
            if os.path.isfile(input_path):
                self.convert_file(input_path, output_path, extension)

            elif os.path.isdir(input_path):
                output_sub_dir = os.path.join(output_path,
                                              os.path.basename(input_path))
                os.makedirs(output_sub_dir)

                contained_files = self.get_file_paths_from_directory(input_path)
                for contained_file in contained_files:
                    self.convert_file(contained_file, output_sub_dir, extension)

    @staticmethod
    def get_file_paths_from_directory(start_directory):
        results = []
        for root, dirs, files in os.walk(start_directory):
            for f in files:
                results.append(os.path.join(root, f))
        return results

    @staticmethod
    def convert_file(input_path, output_path, extension):
        input_file_name = os.path.basename(input_path)
        extension_pos = input_file_name.rfind('.')
        output_file_name = input_file_name[:extension_pos] + extension

        input_imape = Image.open(input_path)
        input_imape.save(os.path.join(output_path, output_file_name))
