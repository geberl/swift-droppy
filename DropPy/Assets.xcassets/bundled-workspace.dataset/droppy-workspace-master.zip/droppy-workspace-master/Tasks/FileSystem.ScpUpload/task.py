#!/usr/bin/python
# -*- coding: utf-8 -*-

import subprocess

# This Task assumes you are authenticating with public keys, not a password.
# And that you already added the fingerprint of your server to your keychain.


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        server_address = kwargs.get('server_address', 'localhost')
        remote_path = kwargs.get('remote_path', '/')
        username = kwargs.get('username', 'my-username')
        executable = kwargs.get('scp_executable', '/usr/bin/scp')

        connection_string = '%s@%s:%s' % (username, server_address, remote_path)

        for input_path in input_paths:
            subprocess.call([executable,
                             '-r',
                             input_path,
                             connection_string])
