#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from PIL import Image


class Task(object):
    def __init__(self, input_paths, output_path, **kwargs):
        degrees = kwargs.get('degrees', 90.0)
        expand = kwargs.get('expand', 1)

        for input_path in input_paths:
            if os.path.isfile(input_path):
                output_file_name = os.path.basename(input_path)

                input_imape = Image.open(input_path)
                output_image = input_imape.rotate(degrees, expand=expand)
                output_image.save(os.path.join(output_path, output_file_name))
